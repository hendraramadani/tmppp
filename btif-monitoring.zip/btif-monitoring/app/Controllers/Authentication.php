<?php

namespace App\Controllers;
use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;

class Authentication extends ResourceController
{
    use ResponseTrait;

    function ldap_auth($nid,$password)
	{
		$LDAP_API_URL = "http://192.168.3.203/ldap_api/auth_opendj/post";

		$payload = array(
			'username' => $nid,
			'password' => $password
		);

		$postdata = http_build_query($payload);
		$opts = array('http' =>
					array(
						'header' => "Content-Type: application/x-www-form-urlencoded\r\n".
									"Content-Length: ".strlen($postdata)."\r\n".
									"User-Agent:MyAgent/1.0\r\n",
						'method'  => 'POST',
						'content' => $postdata
					)
				);
		$context  = stream_context_create($opts);
		$result = file_get_contents($LDAP_API_URL, false, $context);
		echo $result;
		exit;
		return json_decode($result,true);
	}

    public function login() {
        $data = $this->request->getRawInput();
        $res = $this->ldap_auth($data['nid'],$data['password']);
    //     $response = [
    //       'status'   => 201,
    //       'error'    => null,
    //       'messages' => [
    //           'success' => 'User created successfully'
    //       ]
    //   ];
      return $this->respondCreated($res);
    }
}    
